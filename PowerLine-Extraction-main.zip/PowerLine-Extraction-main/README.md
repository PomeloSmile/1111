# 点云电力线提取系统

## 项目简介
本项目为完整的点云电力线提取系统，包含前端界面和后端处理服务。系统支持 LAS 格式点云数据的上传、处理与电力线特征提取，并提供实时可视化和通信反馈。

## 系统架构
- 前端：Vue 3 + Element Plus
- 后端：FastAPI + Open3D
- 通信：WebSocket

## 目录结构
```
.
├── main/                # 前端项目（Vue 3）
│   ├── src/             # 源代码
│   ├── public/          # 静态资源
│   └── package.json     # 依赖配置
│
└── pointcloud-Handel/              # 后端项目（FastAPI）
    ├── pointcloud_predictor.py     # 电力线/电力塔提取
    └── requirements.txt            # 依赖配置
```

## 环境搭建

### 1. Node.js & Vue 环境（前端）
1. 安装 Node.js（推荐 LTS 版本，22.16.0）
   - 下载地址：https://nodejs.org/zh-cn
2. 配置 npm 镜像（国内用户推荐）  
   `npm config set registry https://registry.npmmirror.com`
3. 安装 Vue CLI  
   `npm install -g @vue/cli`
4. 验证安装  
   `node -v`  
   `npm -v`  
   `vue --version`

### 2. Python & FastAPI 环境（后端）
1. 安装 Python 3.12
2. 安装依赖  
   进入 `pointcloud-Handel` 目录，执行：  
   `pip install -r requirements.txt`

## 快速开始

### 1. 启动后端服务
```bash
cd pointcloud-Handel
pip install -r requirements.txt
python main.py
```
服务默认运行在 `http://localhost:8000`

### 2. 启动前端服务
```bash
cd main
npm install
npm run serve
```
前端默认运行在 `http://localhost:8080`

### 3. 访问系统
浏览器访问 `http://localhost:8080`，上传 LAS 文件并进行处理。

## 主要功能
- 支持 LAS 文件上传和处理
- 实时点云处理状态显示
- 电力线特征提取与可视化
- WebSocket 实时通信反馈
- 多线程与异步处理机制

## 前端说明（main/）
- 技术栈：Vue 3、Element Plus、WebSocket、Less、Vue Router、Vuex
- 主要组件：`PointCloudProcessor.vue`（文件上传、处理状态、结果可视化）
- 支持响应式设计与现代化界面
- 运行命令：
  - 安装依赖：`npm install`
  - 启动开发：`npm run serve`
  - 生产构建：`npm run build`
  - 代码检查：`npm run lint`
- WebSocket 地址：`ws://localhost:8080/ws`
- 支持文件格式：`.las`，建议最大 100MB

## 后端说明（pointcloud-Handel/）
- 技术栈：Python 3.12.11、FastAPI、Open3D、NumPy、WebSocket
- 实现功能：点云数据实时处理、电力线提取、WebSocket 通信
- 运行命令：
  - 安装依赖：`pip install -r requirements.txt`
  - 启动服务：`python main.py`
- WebSocket 端点：`ws://localhost:8000/ws`

## 开发计划
- [ ] 支持更多点云文件格式
- [ ] 优化处理算法与可视化
- [ ] 添加批处理与历史记录功能